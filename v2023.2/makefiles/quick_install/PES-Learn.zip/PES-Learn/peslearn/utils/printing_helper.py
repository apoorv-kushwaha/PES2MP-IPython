


def hyperopt_init():
    pass

def hyperopt_complete():
    print("\n###################################################")
    print("#                                                 #")
    print("#     Hyperparameter Optimization Complete!!!     #")
    print("#                                                 #")
    print("###################################################\n")
