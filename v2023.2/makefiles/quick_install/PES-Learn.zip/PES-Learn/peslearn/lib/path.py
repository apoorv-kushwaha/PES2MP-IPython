import os
fi_dir = os.path.dirname(os.path.abspath(__file__)) 
